<?php // index.php

//include header:
define('TITLE', 'Cookie Order Form');
include('C:\xampp\htdocs\final\templates\header.html');

print '<div class="container"><h1>Submit a Cookie Order</h1></div>';
		$submitted = false;
// Check for a form submission:
if ($_SERVER['REQUEST_METHOD'] == 'POST') { // Handle the form.
	
		// Need the database connection:
		include('../mysqli_connect.php');

		// Prepare the values for storing:
		$firstname = mysqli_real_escape_string($dbc, trim(strip_tags($_POST['firstname'])));
		$lastname = mysqli_real_escape_string($dbc, trim(strip_tags($_POST['lastname'])));
		$address = mysqli_real_escape_string($dbc, trim(strip_tags($_POST['address'])));
		$city = mysqli_real_escape_string($dbc, trim(strip_tags($_POST['city'])));
		$state = mysqli_real_escape_string($dbc, trim(strip_tags($_POST['state'])));
		$zip = mysqli_real_escape_string($dbc, trim(strip_tags($_POST['zip'])));
		$email = mysqli_real_escape_string($dbc, trim(strip_tags($_POST['email'])));
		$phone = mysqli_real_escape_string($dbc, trim(strip_tags($_POST['phone'])));
		//modified cookie string to lower case	
		$cookie = mysqli_real_escape_string($dbc, trim(strip_tags(strtolower($_POST['cookie']))));
		$quantity = mysqli_real_escape_string($dbc, trim(strip_tags($_POST['quantity'])));	
		$okay = true;
		$phone = phone_number_format($phone);
	
		//validate phone number:
		if(empty($phone)){
			print('<p class="error">Your phone number was not valid.</p>');
			print('<p class="errorResubmit">Please enter a 10 digit phone number and submit again!</p>');
			$okay=false;
		}
	
		//Validate email for format, and that emails match. Normally I would match the entire email, but am demonstrating comparing two substrings.
		//Also control structure:
		if (!filter_var($email, FILTER_VALIDATE_EMAIL)) { 
			
			//compare substrings
			if(strtok($_POST['email'],'@') != strtok($_POST['confirm'],'@')) {
				//error msg when format and confirmation are incorrect:
				print('<p class="error">**Your email format is invalid.<br>**Your confirmed email does not match.</p>');
				print('<p class="errorResubmit">Please correct your email address and submit again!</p>');
				$okay=false;
			//error msg when only the email format is incorrect:
			}	else {
				print('<p class="errorResubmit"> Please correct your email format and submit again!</p>');	
				$okay=false;
			}
		//error msg when just the emails don't match:
		} else {
			if (strtok($_POST['email'],'@') != strtok($_POST['confirm'],'@')) {
				print('<p class="errorResubmit">Please make your email and confirmation match and submit again!</p>');		
				$okay=false;		
			}
		}
	//code to run if no errors in validations:
	if($okay){
		
	//inserts record in database:	
	$query = "INSERT INTO orders (firstname, lastname, address, city, state, zip, email, phone, cookie, quantity) VALUES ('$firstname', '$lastname', '$address', '$city', '$state', '$zip', '$email', '$phone', '$cookie', '$quantity')";
	
		mysqli_query($dbc, $query);		
			
		//set price, tax variables:
		$price = 6;
		$taxrate = 1.075;
		
		//calculate cost
		$cost = $quantity * $price;
		$cost_with_tax = $cost * $taxrate;	
		$tax = $cost_with_tax - $cost;
		
		//format cost - string concatation:
		$cost = '$' . number_format($cost, 2);
		$cost_with_tax = '$' . number_format($cost_with_tax, 2);
		$tax = '$' . number_format($tax, 2);
		$price = '$' . number_format($price, 2);
		
		//if record is actually added:
		if (mysqli_affected_rows($dbc) == 1){
			$submitted = true;
			// Print a message:
			print("<div class='container'>
			<p>$firstname $lastname, your $cookie cookie order has been submitted.<br>You've ordered $quantity boxes for $cost with a $tax tax, for a total of $cost_with_tax.</p>");
			
			print("<form class='container' action='orders.php'>
         		<button class='button' type='submit'>Click Here to View All Orders</button>
      			</form>");
			print("<br><form class='container' action='index.php'>
         		<button class='button' type='submit'>Make Another Order</button>
      			</form>");
			
		//if record doesn't get added to db:	
		} else {
			print '<p class="error">Could not save your order because:<br>' . mysqli_error($dbc) . '.</p><p>The query being run was: ' . $query . '</p>';
		}

		// Close the connection:
		mysqli_close($dbc);
		
	//if there is an error in the validation:
	} else {
		print '<p class="errorheader">Your order was not submitted.</p>';
	}
	
}// End of submitted IF.

// Leave PHP and display the form:

if(!$submitted){
print('
<body>
	<div class="container">
	<div><p>Each delicious box of 12 cookies are $6.00 each.</p></div>
	
	<form action="index.php" method="post">');
		
		//user-defined function
		make_text_input("firstname", "First Name").
		make_text_input("lastname", "Last Name").
		make_text_input("address", "Street Address").
		make_text_input("city", "City");
	
print('
		<p><label>State</label><br>
		<select name="state" required>
			<option value="" disabled selected hidden>** Select a State **</option>
			<option value="AL">Alabama</option>
			<option value="AK">Alaska</option>
			<option value="AZ">Arizona</option>
			<option value="AR">Arkansas</option>
			<option value="CA">California</option>
			<option value="CO">Colorado</option>
			<option value="CT">Connecticut</option>
			<option value="DE">Delaware</option>
			<option value="DC">District Of Columbia</option>
			<option value="FL">Florida</option>
			<option value="GA">Georgia</option>
			<option value="HI">Hawaii</option>
			<option value="ID">Idaho</option>
			<option value="IL">Illinois</option>
			<option value="IN">Indiana</option>
			<option value="IA">Iowa</option>
			<option value="KS">Kansas</option>
			<option value="KY">Kentucky</option>
			<option value="LA">Louisiana</option>
			<option value="ME">Maine</option>
			<option value="MD">Maryland</option>
			<option value="MA">Massachusetts</option>
			<option value="MI">Michigan</option>
			<option value="MN">Minnesota</option>
			<option value="MS">Mississippi</option>
			<option value="MO">Missouri</option>
			<option value="MT">Montana</option>
			<option value="NE">Nebraska</option>
			<option value="NV">Nevada</option>
			<option value="NH">New Hampshire</option>
			<option value="NJ">New Jersey</option>
			<option value="NM">New Mexico</option>
			<option value="NY">New York</option>
			<option value="NC">North Carolina</option>
			<option value="ND">North Dakota</option>
			<option value="OH">Ohio</option>
			<option value="OK">Oklahoma</option>
			<option value="OR">Oregon</option>
			<option value="PA">Pennsylvania</option>
			<option value="RI">Rhode Island</option>
			<option value="SC">South Carolina</option>
			<option value="SD">South Dakota</option>
			<option value="TN">Tennessee</option>
			<option value="TX">Texas</option>
			<option value="UT">Utah</option>
			<option value="VT">Vermont</option>
			<option value="VA">Virginia</option>
			<option value="WA">Washington</option>
			<option value="WV">West Virginia</option>
			<option value="WI">Wisconsin</option>
			<option value="WY">Wyoming</option>			
		</select></p>');		
	
		sticky_input("<p><label>Zip Code</label><br>
		<input type='text' name='zip' size='50' pattern='[0-9]{5}' required", 'zip').
		sticky_input('<p><label>Email Address</label><br>
		<input type="email" name="email" size="50" required', 'email').
		sticky_input('<p><label>Confirm Email</label><br>
		<input type="email" name="confirm" size="50" required', 'confirm').
		sticky_input('<p><label>Phone Number</label><br>
		<input type="tel" name="phone" size="50" placeholder="555-555-5555" required', 'phone').
		sticky_input('<p><label>Quantity</label><br>
			<input type="number" name="quantity" size="70" min="1" ','quantity').

print('		
		<p><label>Type of cookie</label><br>
        <select name="cookie" required>
			<option value="" disabled selected hidden>** Select a Cookie Type **</option>
			<option value="Oatmeal">Oatmeal</option>
			<option value="Peanut Butter">Peanut Butter</option>
			<option value="Chocolate Chip">Chocolate Chip</option>
        </select></p>

		<input class="submit" type="submit" name="submit" value="Submit My Order">
	</form>
	</div>
</body>	
');
}	
	
include('C:\xampp\htdocs\final\templates\footer.html'); // Include the footer.	
?>
