<?php // - delete_order.php
/* This script deletes an order. */

// Define a page title and include the header:
define('TITLE', 'Delete an Order');
include('templates/header.html');

print '<h1 class="container">Delete an Order</h1>';

// Need the database connection:
include('../mysqli_connect.php');

if (isset($_GET['id']) && is_numeric($_GET['id']) && ($_GET['id'] > 0) ) { // Display the order in a form:

	// Define the query:
	$query = "SELECT *, quantity * 6 * 1.075 AS cost FROM orders WHERE id={$_GET['id']}";
	if ($result = mysqli_query($dbc, $query)) { // Run the query.

		$row = mysqli_fetch_array($result); // Retrieve the information.

		// Make the form:
		print '<form action="delete_order.php" method="post">
		<p class="error">Are you sure you want to delete this order?</p>';
		
		print('<div class="container"><a class="cancelButton" href="/final/orders.php">Do Not Delete This Order</a></div><br>');
		
		
		print '<table id="orders"> 
		  <tr> 
			<th>Order</th> 
			  <th>Name</th> 
			  <th>Address</th> 
			  <th>Email</th> 
			  <th>Phone</th> 
			  <th>Cookie</th> 
			  <th style="text-align:center">Quantity</th> 
			  <th>Cost</th>
		  </tr>';
	  
		$id = $row["id"];
		$firstname = $row["firstname"];
		$lastname = $row["lastname"];
        $address = $row["address"];
		$city = $row["city"];
		$state = $row["state"];
        $zip = $row["zip"];
		$email = $row["email"];
        $phone = $row["phone"];
        $cookie = $row["cookie"]; 
 		$quantity = $row["quantity"];
        $cost = '$' . number_format($row["cost"], 2); 
		
	  	print
	  		'<tr> 
			<td>'.$id.'</td>
			<td>'.$firstname.' '.$lastname.'</td> 
			<td>'.$address.' '.$city.' '.$state.' '.$zip.'</td> 
			<td>'.$email.'</td> 
			<td>'.$phone.'</td> 
			<td>'.$cookie.'</td> 
			<td style="text-align:center">'.$quantity.'</td> 
			<td>'.$cost.'</td> 
    	</tr>';

			print('</table>');
		print '</div><br><input type="hidden" name="id" value="' . $_GET['id'] . '">
		<p><input class="button" type="submit" name="submit" value="Delete this order!"></p>
		</form>';

	} else { // Couldn't get the information.
		print '<p class="error">Could not retrieve the order because:<br>' . mysqli_error($dbc) . '.</p><p>The query being run was: ' . $query . '</p>';
	}

} elseif (isset($_POST['id']) && is_numeric($_POST['id']) && ($_POST['id'] > 0) ) { // Handle the form.

	// Define the query:
	$query = "DELETE FROM orders WHERE id={$_POST['id']} LIMIT 1";
	$result = mysqli_query($dbc, $query); // Execute the query.

	// Report on the result:
	if (mysqli_affected_rows($dbc) == 1) {
		print '<p class="errorResubmit">The order entry has been deleted.</p>';
				
		print("<form class='container' action='orders.php'>
        <button class='button' type='submit'>View All Orders</button>
      	</form>");
		print("<br><form class='container' action='index.php'>
        <button class='button' type='submit'>Make Another Order</button>
      	</form>");
		
	} else {
		print '<p class="error">Could not delete the order entry because:<br>' . mysqli_error($dbc) . '.</p><p>The query being run was: ' . $query . '</p>';
	}

} else { // No ID received.
	print '<p class="error">This page has been accessed in error.</p>';
} // End of main IF.

mysqli_close($dbc); // Close the connection.

include('templates/footer.html');
?>