<?php // - functions.php
/* This page defines custom functions. */

function make_text_input($name, $label, $size = 50) {
	
	// Begin a paragraph and a label:
	print '<p><label>' . $label . '</label><br> ';
	
	// Begin the input:
	print '<input type="text" name="' . $name . '" size="' . $size . '"  required';
	
	// Add the value:
	if (isset($_POST[$name])) {
		print ' value="' . htmlspecialchars($_POST[$name]) . '"';
	}
	
	// Complete the input, the label and the paragraph:
	print '></p>';
	
} // End of make_text_input() function.

function sticky_input($input, $name){
	if (isset($_POST[$name])) {
		print $input . ' value="' . htmlspecialchars($_POST[$name]) . '"></p>';
} else{
		print $input . '></p>';
	}
}

function phone_number_format($number) {
  // Allow only Digits, remove all other characters.
  $number = preg_replace("/[^\d]/","",$number);
 
  // get number length.
  $length = strlen($number);
 
 // if number = 10
 if($length == 10) {
  $number = preg_replace("/^1?(\d{3})(\d{3})(\d{4})$/", "$1-$2-$3", $number);
 } else {
	 $number = "";
 }
  return $number;
 
}

?>