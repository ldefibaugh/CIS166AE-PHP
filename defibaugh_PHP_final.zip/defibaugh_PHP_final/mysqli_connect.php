
<?php // mysqli_connect.php
/* This script connects to the database
and establishes the character set for communications. */

// Connect:
$dbc = mysqli_connect('localhost', 'root', 'RootFruclub*64', 'cookie_orders');

//Set the character set:
mysqli_set_charset($dbc, 'utf8');